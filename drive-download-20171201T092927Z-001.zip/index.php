<?php
session_start();
$gebruikersnaam = $_SESSION['name'];
    if (isset($gebruikersnaam) && !empty($gebruikersnaam)){
        $out = "<p style='color: #16b289; display: inline; font-size: 20px;'>Welcome $gebruikersnaam</p>" . '<a href="login_database.php?logout=true">(LOGOUT)</a>';
    }else{
        $out = '<a href="pages/login.php">LOGIN</a>';
    }
?>
<!DOCTYPE html>
<html lang="nl">
    <head>
        <title>Krashosting - Home</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="CSS/cssreset.css" type="text/css">
        <link rel="stylesheet" href="CSS/stylesheet.css" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Nunito:300,200,900" rel="stylesheet">

    </head>
    <body>
        <header>
            <img src="IMG/banner_krashosting.svg">
        </header>
        <nav>
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="pages/pakketen.php">PAKKETTEN</a></li>
                <li><a href="pages/over_ons.php">OVER ONS</a></li>
                <li><a href="pages/contact.php">CONTACT</a></li>
            </ul>
        </nav>

        <div id="parent_div_mid">
            <div id="child_div1" class="child_div_mid">
                <div class="inner_child_div">
                    <h1 class="title_inner_div">Basic Pakket</h1>
                    <p class="text_child_div">
                        - 3 Maanden<br>
                        - 250mb Webruimte<br>
                        - 10gb data/maand<br>
                        - 5 MySQL Databases
                    </p>
                    <hr class="line_child_div">
                    <h1 class="price_tag">12,-</h1>
                    <a href="pages/pakketen.php" class="button_bestel">Meer info</a>
                </div>
            </div>
            <div id="child_div2" class="child_div_mid">
                <div class="inner_child_div">
                    <h1 class="title_inner_div">Pro Pakket</h1>
                    <p class="text_child_div">
                        - 6 Maanden<br>
                        - 500mb Webruimte<br>
                        - 20gb data/maand<br>
                        - 12 MySQL Databases
                    </p>
                    <hr class="line_child_div">
                    <h1 class="price_tag">20,-</h1>
                    <a href="pages/pakketen.php" class="button_bestel">Meer info</a>
                </div>
            </div>
            <div id="child_div3" class="child_div_mid">
                <div class="inner_child_div">
                    <h1 class="title_inner_div">Ultimate Pakket</h1>
                    <p class="text_child_div">
                        - 12 Maanden<br>
                        - 1000mb Webruimte<br>
                        - 40gb data/maand<br>
                        - 36 MySQL Databases
                    </p>
                    <hr class="line_child_div">
                    <h1 class="price_tag">36,-</h1>
                        <a href="pages/pakketen.php" class="button_bestel">Meer info</a>
                </div>
            </div>
        </div>
        <footer>
            <h1 id="copyright">© 2017 KRASHOSTING ALL RIGHTS RESERVED</h1>
        </footer>
    </body>
</html>
