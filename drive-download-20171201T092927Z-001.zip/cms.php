<?php

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>CMS</title>
        <style>
            a {
                text-decoration: none;
                color: black;
                font-size: 20px;
            }
        </style>
    </head>
    <body>
        <a href="pakketen_tonen.php">Klik hier om <b>pakketen</b> te kunnen toevoegen/aanpassen/verwijderen</a><br>
        <a href="#">Klik hier om <b>nieuws</b> te kunnen toevoegen/aanpassen/verwijderen</a><br>
        <a href="#">Klik hier om je <b>wachtwoord</b> te kunnen aanpassen</a><br>
        <a href="#">Klik hier om <b>uit te loggen</b></a>
    </body>
</html>
